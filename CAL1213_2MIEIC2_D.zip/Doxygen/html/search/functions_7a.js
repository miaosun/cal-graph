var searchData=
[
  ['zona',['Zona',['../class_zona.html#a3688f0be1f396741447def3ad16e393d',1,'Zona::Zona(string designacao)'],['../class_zona.html#a5705452a3ba9676e379b36017697a8db',1,'Zona::Zona(unsigned int codZona, string designacao)']]]
];

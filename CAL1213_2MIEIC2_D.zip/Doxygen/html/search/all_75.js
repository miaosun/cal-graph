var searchData=
[
  ['undirected',['UNDIRECTED',['../class_edge_type.html#a6533cc56d05c288a550b9980b66c9317',1,'EdgeType']]],
  ['unweightedshortestpath',['unweightedShortestPath',['../class_graph.html#ae5264597aacaf4f45819e96a6d6c89aa',1,'Graph']]],
  ['update',['update',['../class_produto.html#abe96b6648db7dd03afdd53eb504eab88',1,'Produto']]],
  ['updateedgeflow',['updateEdgeFlow',['../class_vertex.html#abc0db834c5ea38fa4ceb20f231040e7b',1,'Vertex']]]
];

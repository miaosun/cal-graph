var searchData=
[
  ['algoritmo',['algoritmo',['../_loja_electronica_8cpp.html#a86a678650861b40acf4aee70017eb46d',1,'LojaElectronica.cpp']]]
];

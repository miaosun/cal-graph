var searchData=
[
  ['path',['path',['../class_vertex.html#abd40febd917aa25add6bd42237c8463a',1,'Vertex']]],
  ['pesquisasequencial',['pesquisaSequencial',['../funcoes_8cpp.html#a65fcdf2d7050632f763fafd5936a65f0',1,'pesquisaSequencial(vector&lt; string &gt; v, string s):&#160;funcoes.cpp'],['../funcoes_8h.html#a65fcdf2d7050632f763fafd5936a65f0',1,'pesquisaSequencial(vector&lt; string &gt; v, string s):&#160;funcoes.cpp']]],
  ['procuracliente_5fnome',['ProcuraCliente_nome',['../class_loja_electronica.html#aa050620306680010006d59ae816b1afa',1,'LojaElectronica']]],
  ['procuraencomenda',['procuraEncomenda',['../class_loja_electronica.html#a66ff7b34ddb7b2ad070429be7110ac43',1,'LojaElectronica']]],
  ['procuraloja',['procuraLoja',['../class_loja_electronica.html#a70b7eb14a21ba59e102c6c5902bd6093',1,'LojaElectronica']]],
  ['procuraproduto',['procuraProduto',['../class_loja.html#a73a31c8dfc32a38f736e6eaf395ecdb2',1,'Loja']]],
  ['procurazona',['procuraZona',['../class_loja_electronica.html#acd1dc749c2f6d872edadfdcf8be4e582',1,'LojaElectronica::procuraZona(string designacao)'],['../class_loja_electronica.html#a26cbeb5e234aa8970e89fe86c8e2b060',1,'LojaElectronica::procuraZona(unsigned int id)']]],
  ['produto',['Produto',['../class_produto.html',1,'Produto'],['../class_produto.html#a0dc07d56afcd7a375ab7ab0be3eb3542',1,'Produto::Produto()']]],
  ['produto_2ecpp',['Produto.cpp',['../_produto_8cpp.html',1,'']]],
  ['produto_2eh',['Produto.h',['../_produto_8h.html',1,'']]]
];

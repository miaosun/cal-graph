var searchData=
[
  ['vertex',['Vertex',['../class_vertex.html#afcbdd4d4198b672356559cb8fa088408',1,'Vertex']]]
];

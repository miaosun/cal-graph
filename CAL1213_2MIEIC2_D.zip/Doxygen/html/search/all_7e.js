var searchData=
[
  ['_7elojaelectronica',['~LojaElectronica',['../class_loja_electronica.html#a4a70d423f38c4891cb9f520ffc7f7717',1,'LojaElectronica']]],
  ['_7ezona',['~Zona',['../class_zona.html#a03bc0c59d35379c54daa6c10e05853f3',1,'Zona']]]
];
